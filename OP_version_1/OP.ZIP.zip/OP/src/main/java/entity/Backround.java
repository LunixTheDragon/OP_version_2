package entity;

public class Backround extends Entity{
    public Backround(float x, float y, int width, int height) {
        super(x, y, width, height);
    }
}
