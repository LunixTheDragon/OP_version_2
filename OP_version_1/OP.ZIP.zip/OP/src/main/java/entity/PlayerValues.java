package entity;

public enum PlayerValues {
    IDLE, RUNNING, HIT, GOODPRODUCT
}
